# Detecção de animais no Minecraft 2 > 2024-11-16 6:09pm
https://universe.roboflow.com/cc24/deteccao-de-animais-no-minecraft-2

Provided by a Roboflow user
License: CC BY 4.0

